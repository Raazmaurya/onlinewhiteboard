# OnlineWhiteBoard

OnlineWhiteBoard is a web app that helps users to collaborate their work on a whiteboard online in real time.
The users can pick any color they want and the size of the color. This site includes useful features such as sharing whiteboard with someone else through a link and doing video calls while editing whiteboard. In addtion, this site also provide entertainments such as playing video game and watching animaitons. 

# Installation 

- npm install express

- node server.js

Https://localhost://5000

Https://onlinewhiteboard.herokuapp.com


# Under developement

- Facebook login
- Twitter login 
- Sharing link 
- Redesign Video calls
- Redesign Christmas page


