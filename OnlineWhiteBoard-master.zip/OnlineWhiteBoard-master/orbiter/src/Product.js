//==============================================================================
// PRODUCT CONSTANTS
//==============================================================================
/** @class
    @private */
net.user1.orbiter.Product = new Object();

/** @private */
net.user1.orbiter.Product.clientType     = "Orbiter";
net.user1.orbiter.Product.clientVersion  = new net.user1.orbiter.VersionNumber(2,1,2,19);
net.user1.orbiter.Product.upcVersion     = new net.user1.orbiter.VersionNumber(1,10,3);