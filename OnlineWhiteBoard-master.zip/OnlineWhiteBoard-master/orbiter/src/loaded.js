//==============================================================================
// LOADED FLAG
//==============================================================================
/** 
 * @constant 
 * 
 * Indicates that Orbiter has finished loading.
 */
net.user1.orbiter.LOADED = true;

