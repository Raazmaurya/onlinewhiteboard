//==============================================================================
//  SECURITY_ROLE CONSTANTS
//==============================================================================
/** @class */
net.user1.orbiter.SecurityRole = new Object();
/** @constant */
net.user1.orbiter.SecurityRole.MODERATOR = "MODERATOR";
